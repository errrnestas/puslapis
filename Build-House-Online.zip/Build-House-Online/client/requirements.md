## Packages
framer-motion | Smooth animations for page transitions and card interactions
react-helmet-async | SEO meta tags for title and description management

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  sans: ["'DM Sans'", "sans-serif"],
  display: ["'Outfit'", "sans-serif"],
}
